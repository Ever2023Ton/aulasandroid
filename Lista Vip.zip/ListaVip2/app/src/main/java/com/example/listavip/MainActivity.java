package com.example.listavip;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.listavip.controller.PessoaController;
import com.example.listavip.model.Pessoa;

public class MainActivity extends AppCompatActivity {
    PessoaController controller;
    Pessoa outrapessoa;
    Pessoa pessoa;
    EditText editTextNome;
    EditText editTextSobrenome;
    EditText curso;
    EditText telefone;

    Button btnSalvar;
    Button btnLimpar;
    Button btnFinalizar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        controller=new PessoaController();
        controller.toString();

        outrapessoa = new Pessoa();
        outrapessoa.setPrimeiroNome("Milo");
        outrapessoa.setSobreNome("Loreto");
        outrapessoa.setCursoDesejado("Html");
        outrapessoa.setTelefoneContato("11-992889804");

        pessoa = new Pessoa();
        pessoa.setPrimeiroNome("Everton");
        pessoa.setSobreNome("Pimentel");
        pessoa.setCursoDesejado("Android");
        pessoa.setTelefoneContato("11-992889804");

        editTextNome = findViewById(R.id.editTextNome);
        editTextSobrenome = findViewById(R.id.editTextSobrenome);
        curso = findViewById(R.id.editTextCurso);
        telefone = findViewById(R.id.editTextPhone);

        btnSalvar = findViewById(R.id.buttonSalvar);
        btnLimpar = findViewById(R.id.buttonLimpar);
        btnFinalizar = findViewById(R.id.buttonFinalizar);

        editTextNome.setText(pessoa.getPrimeiroNome().toString());
        editTextSobrenome.setText(pessoa.getSobreNome().toString());
        curso.setText(pessoa.getCursoDesejado().toString());
        telefone.setText(pessoa.getTelefoneContato().toString());
        btnSalvar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                outrapessoa.setPrimeiroNome(editTextNome.getText().toString());
                outrapessoa.setSobreNome(editTextSobrenome.getText().toString());
                outrapessoa.setCursoDesejado(curso.getText().toString());
                outrapessoa.setTelefoneContato(telefone.getText().toString());

                Toast.makeText(MainActivity.this, "Salvo com sucesso" + outrapessoa.toString(), Toast.LENGTH_SHORT).show();

                controller.salvar(outrapessoa);
            }
        });


        btnFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Obrigado pela preferência, volte sempre", Toast.LENGTH_LONG).show();
                finish();
            }
        });

        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextNome.setText("");
                editTextSobrenome.setText("");
                curso.setText("");
                telefone.setText("");
            }
        });

    }

}