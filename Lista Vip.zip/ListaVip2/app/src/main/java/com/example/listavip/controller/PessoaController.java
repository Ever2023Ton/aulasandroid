package com.example.listavip.controller;

import android.util.Log;

import androidx.annotation.NonNull;

import com.example.listavip.model.Pessoa;

public class PessoaController {
    @NonNull
    @Override
    public String toString() {
        Log.d("MVC_controller","PessoaController");
        return super.toString();
    }

    public void salvar(Pessoa outrapessoa) {

        Log.d("MVC_controller","Salvo"+outrapessoa.toString());


    }
}
